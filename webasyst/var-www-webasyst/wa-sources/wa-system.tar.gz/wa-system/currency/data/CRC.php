<?php

return array(
    'code' => 'CRC',
    'sign' => '₡',
	'iso4217' => '188',
    'sign_position' => 0,
    'sign_delim' => '',
    'title' => 'Costa Rican colon',
    'name' => array(
        array('colon', 'colones'),
    ),
    'frac_name' => array(
        array('centimo', 'centimos'),
    )
);