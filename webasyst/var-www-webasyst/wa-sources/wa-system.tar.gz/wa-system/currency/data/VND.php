<?php

return array(
    'code' => 'VND',
    'sign' => '₫',
	'iso4217' => '704',
    'sign_position' => null,	//sign is added AFTER the number without space between them
    'sign_delim' => null,
    'title' => 'Vietnamese dong',
    'name' => array(
        'dong',
    ),
    'frac_name' => array(
    )
);