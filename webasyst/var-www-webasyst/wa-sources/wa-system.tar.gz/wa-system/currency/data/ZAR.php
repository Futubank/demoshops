<?php

return array(
    'code' => 'ZAR',
    'sign' => 'R',
	'iso4217' => '710',
    'sign_position' => 0,
    'sign_delim' => '',
    'title' => 'South African rand',
    'name' => array(
        array('rand', 'rands'),
    ),
    'frac_name' => array(
        array('cent', 'cents'),
    )
);