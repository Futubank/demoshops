<?php

return array(
    'name' => 'Italiano',
    'region' => 'Italia',
    'english_name' => 'Italian',
    'english_region' => 'Italy',
    'amount_in_words' => array(
        'delim' => array(
            10 => '',
            100 => '',
            1000 => ''
        ),
        'offset' => array(
            1 => -1
        ),
        'single' => true
    )

);