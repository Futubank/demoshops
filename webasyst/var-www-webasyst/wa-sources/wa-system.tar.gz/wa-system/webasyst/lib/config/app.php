<?php

return array(
    'name' => 'Webasyst',
    'prefix' => 'webasyst',
    'version' => '1.8.6',
    'critical'=>'1.8.6',
    'vendor' => 'webasyst',
);
